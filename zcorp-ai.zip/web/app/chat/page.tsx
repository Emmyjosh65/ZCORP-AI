 "use client";
import {useEffect,useState} from "react";

type Msg={role:"user"|"assistant";content:string};
export default function Chat(){
 const [messages,setMessages]=useState<Msg[]>([]); const [input,setInput]=useState(""); const [mode,setMode]=useState("CHAT"); const [loading,setLoading]=useState(false);
 useEffect(()=>{const saved=localStorage.getItem("zeus-chat");if(saved)setMessages(JSON.parse(saved))},[]);
 useEffect(()=>localStorage.setItem("zeus-chat",JSON.stringify(messages)),[messages]);
 async function send(){if(!input.trim()||loading)return;const text=input.trim();setInput("");setMessages(m=>[...m,{role:"user",content:text}]);setLoading(true);try{const r=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message:text,mode})});const d=await r.json();if(!r.ok)throw new Error(d.error||"Request failed");setMessages(m=>[...m,{role:"assistant",content:d.text}]);}catch(e){setMessages(m=>[...m,{role:"assistant",content:String(e)}])}finally{setLoading(false)}}
 return <main className="chat"><div className="container" style={{paddingBottom:0}}><div className="actions"><span className="pill">ZEUS AI</span>{["CHAT","RESEARCH","AGENT","CODE"].map(x=><button key={x} className={"btn "+(mode===x?"":"secondary")} onClick={()=>setMode(x)}>{x}</button>)}</div></div><section className="messages">{messages.length===0&&<div className="card"><h2>How can ZEUS help?</h2><p className="muted">Try research mode for current web information, code mode for development, or attach files through the API-ready backend.</p></div>}{messages.map((m,i)=><div key={i} className={"bubble "+m.role}>{m.content}</div>)}{loading&&<div className="bubble assistant">ZEUS is thinking…</div>}</section><div className="composer"><div className="composer-inner"><textarea value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();send()}}} placeholder="Ask ZEUS anything…"/><button className="btn" onClick={send}>Send</button></div></div></main>;
}
