import Link from "next/link";
import { db } from "../../lib/db";
import { getSessionUserId } from "../../lib/auth";
import { redirect } from "next/navigation";

export default async function Dashboard(){
 const id=await getSessionUserId(); if(!id) redirect("/login");
 const u=await db.user.findUnique({where:{id},include:{memories:true,payments:true}});
 if(!u) redirect("/login");
 return <main className="container"><div className="eyebrow">USER DASHBOARD</div><h1>Welcome, {u.username}</h1><div className="grid"><div className="card"><h3>Tier</h3><p className="pill">{u.tier}</p></div><div className="card"><h3>Memory</h3><p>{u.memories.length} saved memories</p></div><div className="card"><h3>Payments</h3><p>{u.payments.length} submissions</p></div></div><div className="actions"><Link className="btn" href="/chat">Open AI</Link><Link className="btn secondary" href="/upgrade">Upgrade</Link>{u.isAdmin&&<Link className="btn secondary" href="/admin">Admin</Link>}</div></main>;
}
