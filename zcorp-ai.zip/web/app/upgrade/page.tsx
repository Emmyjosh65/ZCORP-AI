 "use client";
import {useState} from "react";
import {TIERS} from "../../lib/tiers";

export default function Upgrade(){
 const [tier,setTier]=useState("PRO");const [reference,setReference]=useState("");const [note,setNote]=useState("");const [message,setMessage]=useState("");
 async function submit(){const r=await fetch("/api/payment-notification",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({tier,reference,note})});const d=await r.json();setMessage(d.message||d.error||"Submitted");}
 const t=TIERS[tier as keyof typeof TIERS];
 return <main className="container"><div className="eyebrow">UPGRADE</div><h1>Choose your tier</h1><div className="grid">{Object.entries(TIERS).filter(([k])=>k!=="FREE").map(([k,v])=><button key={k} className={"card "+(tier===k?"":"")} onClick={()=>setTier(k)} style={{textAlign:"left",cursor:"pointer"}}><span className="pill">{k}</span><h3>{v.name}</h3><p className="muted">{v.description}</p><strong>₦{v.price.toLocaleString()}/month</strong></button>)}</div><div className="card" style={{marginTop:20}}><h2>Pay via Opay</h2><p>Account: <strong>{process.env.NEXT_PUBLIC_PAYMENT_ACCOUNT_NUMBER||"9066760078"}</strong></p><p>Provider: <strong>{process.env.NEXT_PUBLIC_PAYMENT_PROVIDER||"Opay"}</strong></p><p>Name: <strong>{process.env.NEXT_PUBLIC_PAYMENT_ACCOUNT_NAME||"CHRISTANA Godwin okon"}</strong></p><p className="muted">Selected: {t.name} — ₦{t.price.toLocaleString()}/month</p><div className="field"><label>Payment reference (optional)</label><input value={reference} onChange={e=>setReference(e.target.value)}/></div><div className="field"><label>Note</label><textarea value={note} onChange={e=>setNote(e.target.value)} placeholder="Tell ZCORP what you paid for."/></div><button className="btn" onClick={submit}>Submit payment notification</button>{message&&<p className="notice">{message}</p>}</div></main>;
}
