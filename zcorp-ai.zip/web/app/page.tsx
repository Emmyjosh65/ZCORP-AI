import Link from "next/link";
import { TIERS } from "../lib/tiers";

export default function Home() {
  return <main className="container">
    <section className="hero">
      <div className="eyebrow">ZCORP ORG presents</div>
      <h1>ZEUS<br/>AI</h1>
      <p>A premium, mobile-first AI workspace for chat, research, files, memory, agent workflows, coding and voice — powered by Gemini.</p>
      <div className="actions" style={{justifyContent:"center"}}>
        <Link className="btn" href="/register">Create account</Link>
        <Link className="btn secondary" href="/chat">Open ZEUS</Link>
      </div>
    </section>
    <section className="grid">
      {Object.entries(TIERS).map(([key,t]) => <div className="card" key={key}>
        <span className="pill">{key}</span>
        <h3>{t.name}</h3>
        <p className="muted">{t.description}</p>
        <strong>{t.price === 0 ? "Free" : `₦${t.price.toLocaleString()}/month`}</strong>
      </div>)}
    </section>
    <section className="card" style={{marginTop:20}}>
      <h3>ZCORP ORG</h3>
      <p className="muted">BUILD. CREATE. SELL. INNOVATE.</p>
      <p className="muted">ZCORP ORG builds modern websites, web applications, dashboards, gaming platforms, digital tools and custom digital experiences.</p>
      <div className="actions">
        <a className="btn secondary" href={process.env.ZCORP_WEBSITE || "https://zcorp-org-co.vercel.app/"}>Official website</a>
        <a className="btn secondary" href={process.env.ZCORP_WHATSAPP_CHANNEL || "https://whatsapp.com/channel/0029VbCoI29AYlUOb6Bdpo30"}>WhatsApp channel</a>
        <a className="btn secondary" href={process.env.ZCORP_TELEGRAM_CHANNEL || "https://t.me/zcorporg"}>Telegram</a>
      </div>
    </section>
  </main>;
}
