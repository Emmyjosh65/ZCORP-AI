 "use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function Register() {
  const router=useRouter(); const [username,setUsername]=useState(""); const [password,setPassword]=useState(""); const [agree,setAgree]=useState(false); const [error,setError]=useState("");
  async function submit(e:React.FormEvent){e.preventDefault();setError("");const r=await fetch("/api/auth/register",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({username,password,agree})});const d=await r.json();if(!r.ok){setError(d.error||"Registration failed");return}router.push("/dashboard")}
  return <main className="container"><form className="card form" onSubmit={submit}><div className="eyebrow">CREATE ACCOUNT</div><h1>Join ZEUS</h1><div className="field"><label>Username</label><input value={username} onChange={e=>setUsername(e.target.value)} minLength={3} maxLength={32} required/></div><div className="field"><label>Password</label><input type="password" value={password} onChange={e=>setPassword(e.target.value)} minLength={8} required/></div><div className="policy">ZCORP AI Usage & Membership Policy{"\n\n"}By creating an account, you agree to use the service lawfully and responsibly. Your account credentials must remain private. AI output should be verified before important decisions. Premium access may be revoked for abuse.</div><div className="field"><label><input type="checkbox" checked={agree} onChange={e=>setAgree(e.target.checked)} required/> I have read and agree to the ZCORP policy.</label></div>{error&&<p className="notice">{error}</p>}<button className="btn" type="submit">Create account</button></form></main>;
}
