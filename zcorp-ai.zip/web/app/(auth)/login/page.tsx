 "use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function Login() {
  const router=useRouter(); const [username,setUsername]=useState(""); const [password,setPassword]=useState(""); const [error,setError]=useState("");
  async function submit(e:React.FormEvent){e.preventDefault();setError("");const r=await fetch("/api/auth/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({username,password})});const d=await r.json();if(!r.ok){setError(d.error||"Login failed");return}router.push("/dashboard")}
  return <main className="container"><form className="card form" onSubmit={submit}><div className="eyebrow">ZCORP AI</div><h1>Sign in</h1><div className="field"><label>Username</label><input value={username} onChange={e=>setUsername(e.target.value)} required autoComplete="username"/></div><div className="field"><label>Password</label><input type="password" value={password} onChange={e=>setPassword(e.target.value)} required autoComplete="current-password"/></div>{error&&<p className="notice">{error}</p>}<button className="btn" type="submit">Sign in</button><p className="muted">New here? <Link href="/register">Create an account</Link></p></form></main>;
}
