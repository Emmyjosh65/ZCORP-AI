import "./globals.css";
import Link from "next/link";

export const metadata = {
  title: "ZCORP AI — ZEUS",
  description: "Premium AI platform by ZCORP ORG"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="shell">
      <header className="nav">
        <Link href="/" className="brand">👑 ZEUS</Link>
        <nav className="navlinks">
          <Link href="/chat">AI</Link>
          <Link href="/upgrade">Upgrade</Link>
          <Link href="/dashboard">Dashboard</Link>
          <Link href="/login">Sign in</Link>
        </nav>
      </header>
      {children}
    </div>
  );
}
