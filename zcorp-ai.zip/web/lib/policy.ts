export const ZCORP_POLICY = {
  title: "ZCORP AI Usage & Membership Policy",
  version: "1.0",
  text: `By creating a ZCORP AI account, you agree to use the service lawfully and responsibly.

1. Account security: Keep your username and password private. Do not share or sell account access.
2. AI output: AI responses can be wrong. Verify important information before relying on it.
3. Prohibited use: Do not use ZCORP AI for fraud, abuse, credential theft, malware distribution, harassment, or unlawful activity.
4. Files: Only upload files you are authorized to use. Do not upload confidential material unless you understand the risks and have permission.
5. Premium access: Paid tiers and premium codes are for the intended account. Codes may be revoked if abused.
6. Payments: A payment request is not proof of payment. ZCORP may review and approve payment submissions.
7. Availability: Features, models, limits and pricing may change.
8. Privacy: ZCORP should minimize stored data and should not place API secrets in browser code.
9. Enforcement: ZCORP may suspend accounts that violate this policy.
10. Contact: Use the official ZCORP contact channels for support.

By checking the agreement box, you confirm that you have read and accepted this policy.`
};
