export async function sendWhatsAppMessage(message: string) {
  const token = process.env.WHATSAPP_ACCESS_TOKEN;
  const phoneNumberId = process.env.WHATSAPP_PHONE_NUMBER_ID;
  const recipient = process.env.WHATSAPP_RECIPIENT_NUMBER;

  if (!token || !phoneNumberId || !recipient) {
    return {
      sent: false,
      fallbackUrl: `https://wa.me/${(process.env.ZCORP_WHATSAPP || "9066760078").replace(/\D/g, "")}?text=${encodeURIComponent(message)}`
    };
  }

  const res = await fetch(`https://graph.facebook.com/v23.0/${phoneNumberId}/messages`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      to: recipient.replace(/\D/g, ""),
      type: "text",
      text: { body: message }
    })
  });

  if (!res.ok) throw new Error(`WhatsApp API error: ${await res.text()}`);
  return { sent: true };
}
