import crypto from "node:crypto";
import { db } from "./db";
import type { Tier } from "@prisma/client";

function hashCode(code: string) {
  return crypto.createHash("sha256").update(code.trim()).digest("hex");
}

export async function seedPremiumCodes() {
  const raw = process.env.PREMIUM_CODES || "";
  if (!raw) return;

  const codes = raw.split(",").map((x) => x.trim()).filter(Boolean);
  for (const code of codes) {
    const codeHash = hashCode(code);
    await db.premiumCode.upsert({
      where: { codeHash },
      update: {},
      create: { codeHash, tier: "PRO" }
    });
  }
}

export async function redeemPremiumCode(userId: string, code: string) {
  const codeHash = hashCode(code);
  const found = await db.premiumCode.findUnique({ where: { codeHash } });
  if (!found || found.redeemed) return false;

  await db.$transaction([
    db.premiumCode.update({
      where: { id: found.id },
      data: { redeemed: true, redeemedBy: userId, redeemedAt: new Date() }
    }),
    db.user.update({ where: { id: userId }, data: { tier: found.tier as Tier } })
  ]);
  return true;
}
