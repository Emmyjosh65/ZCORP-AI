import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.GEMINI_API_KEY;

if (!apiKey) {
  console.warn("GEMINI_API_KEY is not configured.");
}

export const gemini = apiKey ? new GoogleGenAI({ apiKey }) : null;

export async function runGemini(input: string, mode: "CHAT" | "RESEARCH" | "AGENT" | "CODE") {
  if (!gemini) throw new Error("Gemini API is not configured.");

  const tools = mode === "RESEARCH" ? [{ googleSearch: {} }] : undefined;
  const system =
    mode === "CODE"
      ? "You are ZEUS, the ZCORP AI coding assistant. Give safe, production-quality code and explain assumptions briefly."
      : mode === "AGENT"
      ? "You are ZEUS Agent. Break complex tasks into clear steps, but do not claim to have taken real-world actions you cannot perform."
      : mode === "RESEARCH"
      ? "You are ZEUS Research. Prefer current, verifiable information and cite sources returned by the search tool."
      : "You are ZEUS, the AI assistant for ZCORP AI. Be useful, concise, and honest.";

  const response = await gemini.models.generateContent({
    model: "gemini-3.7-flash",
    contents: `${system}\n\nUser:\n${input}`,
    config: tools ? { tools } : undefined
  });

  return response.text || "No response generated.";
}
