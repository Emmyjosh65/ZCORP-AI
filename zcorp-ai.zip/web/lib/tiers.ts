export const TIERS = {
  FREE: { name: "Free", description: "Essential AI access", price: 0 },
  PLUS: { name: "Plus", description: "More usage and premium tools", price: 5000 },
  PRO: { name: "Pro", description: "Advanced AI workflows", price: 10000 },
  ULTRA: { name: "Ultra", description: "Maximum ZCORP AI access", price: 20000 }
} as const;

export type TierKey = keyof typeof TIERS;
