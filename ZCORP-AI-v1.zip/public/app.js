const state = {
  user: null,
  conversation: null,
  conversations: [],
  mode: 'instant',
  authRegister: false
};

const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];

function escapeHtml(s) {
  return s.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
}

function show(id){ $('#'+id)?.classList.remove('hidden'); }
function hide(id){ $('#'+id)?.classList.add('hidden'); }

async function api(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: {'Content-Type':'application/json', ...(options.headers || {})}
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || 'Something went wrong.');
  return data;
}

function addMessage(role, content) {
  $('#welcome').classList.add('hidden');
  const wrap = document.createElement('div');
  wrap.className = `message ${role}`;
  wrap.innerHTML = `<div><div class="message-label">${role === 'user' ? 'You' : 'ZEUS'}</div><div class="bubble">${escapeHtml(content)}</div></div>`;
  $('#messages').appendChild(wrap);
  $('#chatView').scrollTop = $('#chatView').scrollHeight;
}

function addTyping() {
  const wrap = document.createElement('div');
  wrap.className = 'message assistant';
  wrap.id = 'typing';
  wrap.innerHTML = `<div><div class="message-label">ZEUS</div><div class="bubble typing"><i></i><i></i><i></i></div></div>`;
  $('#messages').appendChild(wrap);
  $('#chatView').scrollTop = $('#chatView').scrollHeight;
}

function removeTyping(){ $('#typing')?.remove(); }

async function loadMe() {
  try {
    const data = await api('/api/auth/me');
    state.user = data.user;
    updateAccountUI();
  } catch {
    state.user = null;
    updateAccountUI();
  }
}

function updateAccountUI() {
  const user = state.user;
  $('#accountBtn').textContent = user ? user.name.slice(0,1).toUpperCase() : '?';
  $('#planBadge').textContent = (user?.plan || 'free').toUpperCase();
  $('#planTitle').textContent = user ? `ZEUS ${capitalize(user.plan)}` : 'ZEUS Free';
  $('#usageText').textContent = user ? `${user.email}` : 'Sign in to start';
  $('#settingsAccount').textContent = user ? user.email : 'Not signed in';
  $('#settingsPlan').textContent = capitalize(user?.plan || 'free');
}

function capitalize(x){ return x.charAt(0).toUpperCase()+x.slice(1); }

async function loadConversations() {
  if (!state.user) return;
  const data = await api('/api/chat/conversations');
  state.conversations = data.conversations;
  $('#conversationList').innerHTML = state.conversations.map(c =>
    `<div class="history-item" data-id="${c.id}">${escapeHtml(c.title)}</div>`
  ).join('');
}

async function newConversation() {
  if (!state.user) return show('authModal');
  const data = await api('/api/chat/conversations', {
    method:'POST', body:JSON.stringify({mode:state.mode})
  });
  state.conversation = data.conversation;
  $('#messages').innerHTML = '';
  $('#welcome').classList.remove('hidden');
  await loadConversations();
}

async function openConversation(id) {
  const data = await api(`/api/chat/conversations/${id}/messages`);
  state.conversation = state.conversations.find(c => String(c.id) === String(id)) || {id};
  $('#messages').innerHTML = '';
  $('#welcome').classList.add('hidden');
  data.messages.forEach(m => addMessage(m.role, m.content));
  $('#sidebar').classList.remove('open');
}

async function sendMessage(text) {
  if (!state.user) {
    show('authModal');
    return;
  }
  if (!state.conversation) await newConversation();
  addMessage('user', text);
  addTyping();
  $('#messageInput').value = '';
  resizeTextarea();

  try {
    const data = await api('/api/chat/message', {
      method:'POST',
      body:JSON.stringify({
        conversationId: state.conversation.id,
        message: text,
        mode: state.mode
      })
    });
    removeTyping();
    addMessage('assistant', data.message.content);
    $('#usageText').textContent = `${data.usage.used}/${data.usage.limit} messages this month`;
    await loadConversations();
  } catch (error) {
    removeTyping();
    addMessage('assistant', `⚠️ ${error.message}`);
    if (error.message.includes('requires a higher') || error.message.includes('monthly message limit')) showUpgrade();
  }
}

function showUpgrade() {
  show('upgradeModal');
  loadPricing();
}

async function loadPricing() {
  const data = await api('/api/billing/plans');
  $('#pricing').innerHTML = data.plans.filter(p=>p.id!=='free').map(p => `
    <div class="price-card ${p.id==='pro'?'featured':''}">
      <span class="eyebrow">${p.id==='pro'?'MOST POPULAR':'ZEUS'}</span>
      <h3>${capitalize(p.name)}</h3>
      <div class="price">₦${p.price.toLocaleString()}<small>/mo</small></div>
      <ul>
        <li>Higher AI limits</li>
        <li>Premium workspace access</li>
        <li>${p.id==='plus'?'Research mode':p.id==='pro'?'Code + research':'Agent-ready workflows'}</li>
      </ul>
      <button data-plan="${p.id}">Upgrade to ${capitalize(p.name)}</button>
    </div>
  `).join('');
}

async function upgrade(plan) {
  if (!state.user) return show('authModal');
  try {
    const data = await api('/api/billing/initialize', {
      method:'POST', body:JSON.stringify({plan})
    });
    window.location.href = data.authorization_url;
  } catch (error) {
    alert(error.message);
  }
}

function resizeTextarea() {
  const el = $('#messageInput');
  el.style.height = 'auto';
  el.style.height = Math.min(el.scrollHeight, 180) + 'px';
}

function setAuthMode(register) {
  state.authRegister = register;
  $('#authTitle').textContent = register ? 'Create your ZEUS account' : 'Welcome back';
  $('#authSubtitle').textContent = register ? 'Start with ZEUS Free. Upgrade whenever you need more.' : 'Sign in to your ZCORP AI workspace.';
  $('#authSubmit').textContent = register ? 'Create account' : 'Sign in';
  $('#authToggle').textContent = register ? 'Already have an account? Sign in' : 'Create an account';
  $('#authName').classList.toggle('hidden', !register);
  $('#authName').required = register;
  $('#authPassword').autocomplete = register ? 'new-password' : 'current-password';
}

$('#authForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  $('#authError').textContent = '';
  try {
    const payload = {
      name: $('#authName').value,
      email: $('#authEmail').value,
      password: $('#authPassword').value
    };
    const data = await api(state.authRegister ? '/api/auth/register' : '/api/auth/login', {
      method:'POST', body:JSON.stringify(payload)
    });
    state.user = data.user;
    hide('authModal');
    updateAccountUI();
    await loadConversations();
    if (!state.conversation) await newConversation();
  } catch(error) {
    $('#authError').textContent = error.message;
  }
});

$('#authToggle').addEventListener('click', () => setAuthMode(!state.authRegister));
$('#accountBtn').addEventListener('click', () => state.user ? show('settingsModal') : show('authModal'));
$('#newChatBtn').addEventListener('click', newConversation);
$('#upgradeMiniBtn').addEventListener('click', showUpgrade);
$('#menuBtn').addEventListener('click', () => $('#sidebar').classList.toggle('open'));
$('#logoutBtn').addEventListener('click', async () => {
  await api('/api/auth/logout', {method:'POST'});
  state.user = null; state.conversation = null; state.conversations = [];
  $('#conversationList').innerHTML = '';
  hide('settingsModal');
  updateAccountUI();
  $('#messages').innerHTML = '';
  $('#welcome').classList.remove('hidden');
});

$('#composer').addEventListener('submit', async (e) => {
  e.preventDefault();
  const text = $('#messageInput').value.trim();
  if (text) await sendMessage(text);
});

$('#messageInput').addEventListener('keydown', e => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    $('#composer').requestSubmit();
  }
});
$('#messageInput').addEventListener('input', resizeTextarea);

$$('.mode').forEach(btn => btn.addEventListener('click', () => {
  state.mode = btn.dataset.mode;
  $$('.mode').forEach(x => x.classList.remove('active'));
  btn.classList.add('active');
}));

$$('.quick').forEach(btn => btn.addEventListener('click', () => {
  $('#messageInput').value = btn.dataset.prompt;
  resizeTextarea();
  $('#messageInput').focus();
}));

$$('[data-action]').forEach(btn => btn.addEventListener('click', () => {
  if (btn.dataset.action === 'upgrade') showUpgrade();
  if (btn.dataset.action === 'settings') show('settingsModal');
  if (btn.dataset.action === 'chat') $('#messageInput').focus();
}));

document.addEventListener('click', async (e) => {
  const history = e.target.closest('.history-item');
  if (history) await openConversation(history.dataset.id);
  const plan = e.target.closest('[data-plan]');
  if (plan) await upgrade(plan.dataset.plan);
  const close = e.target.closest('[data-close]');
  if (close) hide(close.dataset.close);
});

setAuthMode(false);
loadMe().then(async () => {
  if (state.user) {
    await loadConversations();
    if (state.conversations.length) await openConversation(state.conversations[0].id);
  }
});
