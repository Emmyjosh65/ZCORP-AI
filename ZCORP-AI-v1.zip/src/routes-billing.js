import express from 'express';
import crypto from 'node:crypto';
import { requireAuth } from './auth.js';
import { query } from './db.js';
import { PRICE_NGN, PAYSTACK_PLAN_CODES } from './plans.js';

const router = express.Router();

async function paystack(pathname, options = {}) {
  const response = await fetch(`https://api.paystack.co${pathname}`, {
    ...options,
    headers: {
      Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}`,
      'Content-Type': 'application/json',
      ...(options.headers || {})
    }
  });
  const data = await response.json();
  if (!response.ok || !data.status) throw new Error(data.message || 'Paystack request failed.');
  return data;
}

router.get('/plans', (_req, res) => {
  res.json({
    currency: 'NGN',
    plans: [
      { id: 'free', name: 'Free', price: 0 },
      { id: 'plus', name: 'Plus', price: PRICE_NGN.plus },
      { id: 'pro', name: 'Pro', price: PRICE_NGN.pro },
      { id: 'ultra', name: 'Ultra', price: PRICE_NGN.ultra }
    ]
  });
});

router.post('/initialize', requireAuth, async (req, res) => {
  try {
    if (!process.env.PAYSTACK_SECRET_KEY) {
      return res.status(503).json({ error: 'Billing is not configured yet.' });
    }

    const plan = String(req.body.plan || '').toLowerCase();
    if (!['plus','pro','ultra'].includes(plan)) return res.status(400).json({ error: 'Invalid plan.' });

    const userResult = await query('SELECT id,email FROM users WHERE id=$1', [req.auth.sub]);
    const user = userResult.rows[0];
    if (!user) return res.status(404).json({ error: 'User not found.' });

    const amountNgn = PRICE_NGN[plan];
    const planCode = PAYSTACK_PLAN_CODES[plan];
    if (!planCode) {
      return res.status(503).json({ error: `Paystack ${plan} subscription plan is not configured yet.` });
    }
    const reference = `zcorp_${Date.now()}_${crypto.randomBytes(5).toString('hex')}`;

    await query(
      'INSERT INTO payments(user_id,reference,plan,amount_kobo) VALUES($1,$2,$3,$4)',
      [user.id, reference, plan, amountNgn * 100]
    );

    const data = await paystack('/transaction/initialize', {
      method: 'POST',
      body: JSON.stringify({
        email: user.email,
        amount: String(amountNgn * 100),
        currency: 'NGN',
        reference,
        plan: planCode,
        callback_url: `${process.env.APP_URL}/?payment=complete`,
        metadata: { user_id: String(user.id), plan }
      })
    });

    res.json({
      authorization_url: data.data.authorization_url,
      access_code: data.data.access_code,
      reference: data.data.reference
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: error.message || 'Could not initialize payment.' });
  }
});

router.post('/webhook', express.raw({ type: 'application/json' }), async (req, res) => {
  try {
    const signature = req.headers['x-paystack-signature'];
    const expected = crypto
      .createHmac('sha512', process.env.PAYSTACK_SECRET_KEY || '')
      .update(req.body)
      .digest('hex');

    if (!signature || signature !== expected) return res.status(401).send('Invalid signature');

    const event = JSON.parse(req.body.toString('utf8'));
    if (event.event !== 'charge.success') return res.sendStatus(200);

    const data = event.data;
    const reference = data.reference;
    const amount = Number(data.amount);

    const payment = await query('SELECT * FROM payments WHERE reference=$1', [reference]);
    if (!payment.rowCount) return res.sendStatus(200);

    const row = payment.rows[0];
    if (amount !== row.amount_kobo) return res.status(400).send('Amount mismatch');

    await query(
      'UPDATE payments SET status=$1,paid_at=NOW() WHERE reference=$2',
      ['paid', reference]
    );

    await query(
      'UPDATE users SET plan=$1 WHERE id=$2',
      [row.plan, row.user_id]
    );

    return res.sendStatus(200);
  } catch (error) {
    console.error(error);
    return res.sendStatus(200);
  }
});

router.get('/verify/:reference', requireAuth, async (req, res) => {
  try {
    if (!process.env.PAYSTACK_SECRET_KEY) return res.status(503).json({ error: 'Billing is not configured.' });

    const data = await paystack(`/transaction/verify/${encodeURIComponent(req.params.reference)}`);
    const tx = data.data;

    const payment = await query(
      'SELECT * FROM payments WHERE reference=$1 AND user_id=$2',
      [req.params.reference, req.auth.sub]
    );
    if (!payment.rowCount) return res.status(404).json({ error: 'Payment not found.' });

    const row = payment.rows[0];
    if (tx.status !== 'success' || Number(tx.amount) !== row.amount_kobo) {
      return res.status(400).json({ error: 'Payment could not be verified.' });
    }

    await query('UPDATE payments SET status=$1,paid_at=NOW() WHERE reference=$2', ['paid', row.reference]);
    await query('UPDATE users SET plan=$1 WHERE id=$2', [row.plan, row.user_id]);

    res.json({ ok: true, plan: row.plan });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: error.message || 'Verification failed.' });
  }
});

export default router;
