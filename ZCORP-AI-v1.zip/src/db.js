import pg from 'pg';
import fs from 'node:fs/promises';
import path from 'node:path';

const { Pool } = pg;

if (!process.env.DATABASE_URL) {
  console.warn('DATABASE_URL is not set. Configure PostgreSQL before production.');
}

export const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : undefined
});

export async function initDb() {
  if (!process.env.DATABASE_URL) return;
  const schema = await fs.readFile(path.resolve('schema.sql'), 'utf8');
  await pool.query(schema);
}

export async function query(text, params = []) {
  return pool.query(text, params);
}
