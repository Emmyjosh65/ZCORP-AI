export const PLANS = {
  free: {
    label: 'Free',
    monthlyMessages: 25,
    features: ['Instant AI', 'Basic history', 'Basic memory-ready architecture']
  },
  plus: {
    label: 'Plus',
    monthlyMessages: 500,
    features: ['Higher limits', 'Web research-ready mode', 'Longer conversations', 'Priority access']
  },
  pro: {
    label: 'Pro',
    monthlyMessages: 2500,
    features: ['Advanced reasoning', 'Research', 'Code mode', 'File intelligence-ready', 'Priority compute']
  },
  ultra: {
    label: 'Ultra',
    monthlyMessages: 10000,
    features: ['Maximum limits', 'Agent-ready workflows', 'Advanced research', 'Premium support', 'Early features']
  }
};

export const PRICE_NGN = {
  plus: Number(process.env.PLUS_PRICE_NGN || 9900),
  pro: Number(process.env.PRO_PRICE_NGN || 24900),
  ultra: Number(process.env.ULTRA_PRICE_NGN || 49900)
};

export const PAYSTACK_PLAN_CODES = {
  plus: process.env.PAYSTACK_PLUS_PLAN_CODE || '',
  pro: process.env.PAYSTACK_PRO_PLAN_CODE || '',
  ultra: process.env.PAYSTACK_ULTRA_PLAN_CODE || ''
};

export function canUsePlan(plan, feature) {
  const order = { free: 0, plus: 1, pro: 2, ultra: 3 };
  const required = {
    instant: 0,
    research: 1,
    code: 2,
    agent: 2
  };
  return (order[plan] ?? 0) >= (required[feature] ?? 0);
}
