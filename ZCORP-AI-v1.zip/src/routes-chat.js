import express from 'express';
import { requireAuth } from './auth.js';
import { query } from './db.js';
import { generateReply } from './gemini.js';
import { PLANS, canUsePlan } from './plans.js';

const router = express.Router();

function monthKey() {
  const d = new Date();
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`;
}

async function getUser(id) {
  const result = await query('SELECT id,name,email,plan FROM users WHERE id=$1', [id]);
  return result.rows[0];
}

router.get('/conversations', requireAuth, async (req, res) => {
  const result = await query(
    'SELECT id,title,mode,created_at,updated_at FROM conversations WHERE user_id=$1 ORDER BY updated_at DESC LIMIT 100',
    [req.auth.sub]
  );
  res.json({ conversations: result.rows });
});

router.get('/conversations/:id/messages', requireAuth, async (req, res) => {
  const result = await query(
    `SELECT m.id,m.role,m.content,m.created_at
     FROM messages m JOIN conversations c ON c.id=m.conversation_id
     WHERE m.conversation_id=$1 AND c.user_id=$2
     ORDER BY m.created_at ASC`,
    [req.params.id, req.auth.sub]
  );
  res.json({ messages: result.rows });
});

router.post('/conversations', requireAuth, async (req, res) => {
  const mode = ['instant','research','code','agent'].includes(req.body.mode) ? req.body.mode : 'instant';
  const result = await query(
    'INSERT INTO conversations (user_id,title,mode) VALUES ($1,$2,$3) RETURNING id,title,mode',
    [req.auth.sub, 'New conversation', mode]
  );
  res.status(201).json({ conversation: result.rows[0] });
});

router.post('/message', requireAuth, async (req, res) => {
  try {
    const user = await getUser(req.auth.sub);
    const input = String(req.body.message || '').trim();
    const mode = ['instant','research','code','agent'].includes(req.body.mode) ? req.body.mode : 'instant';
    const conversationId = Number(req.body.conversationId);

    if (!input) return res.status(400).json({ error: 'Message cannot be empty.' });
    if (input.length > 12000) return res.status(400).json({ error: 'Message is too long.' });
    if (!conversationId) return res.status(400).json({ error: 'Conversation is required.' });
    if (!canUsePlan(user.plan, mode)) {
      return res.status(403).json({ error: `The ${mode} mode requires a higher ZEUS plan.` });
    }

    const conversation = await query(
      'SELECT * FROM conversations WHERE id=$1 AND user_id=$2',
      [conversationId, user.id]
    );
    if (!conversation.rowCount) return res.status(404).json({ error: 'Conversation not found.' });

    const key = monthKey();
    const usage = await query(
      `INSERT INTO usage_monthly(user_id,month_key,messages_used)
       VALUES($1,$2,1)
       ON CONFLICT(user_id,month_key)
       DO UPDATE SET messages_used=usage_monthly.messages_used+1
       RETURNING messages_used`,
      [user.id, key]
    );

    const limit = PLANS[user.plan]?.monthlyMessages ?? 25;
    if (usage.rows[0].messages_used > limit) {
      await query(
        'UPDATE usage_monthly SET messages_used=messages_used-1 WHERE user_id=$1 AND month_key=$2',
        [user.id, key]
      );
      return res.status(429).json({ error: `You have reached the ${PLANS[user.plan].label} monthly message limit. Upgrade to continue.` });
    }

    await query(
      'INSERT INTO messages(conversation_id,role,content) VALUES($1,$2,$3)',
      [conversationId, 'user', input]
    );

    const previousId = conversation.rows[0].gemini_interaction_id || undefined;
    const answer = await generateReply({
      input,
      previousInteractionId: previousId,
      mode,
      plan: user.plan
    });

    await query(
      'INSERT INTO messages(conversation_id,role,content) VALUES($1,$2,$3)',
      [conversationId, 'assistant', answer.text]
    );

    const title = conversation.rows[0].title === 'New conversation'
      ? input.slice(0, 60) + (input.length > 60 ? '…' : '')
      : conversation.rows[0].title;

    await query(
      'UPDATE conversations SET title=$1,mode=$2,gemini_interaction_id=$3,updated_at=NOW() WHERE id=$4',
      [title, mode, answer.id, conversationId]
    );

    res.json({
      message: { role: 'assistant', content: answer.text },
      interactionId: answer.id,
      usage: { used: usage.rows[0].messages_used, limit }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: error.message || 'ZEUS could not respond.' });
  }
});

export default router;
