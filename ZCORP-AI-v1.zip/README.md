# ZCORP AI

**ZCORP AI** is a premium AI workspace for ZCORP ORG, powered by Google's Gemini API.

> Build. Create. Sell. Innovate.

## Included in this starter

- Premium dark AI workspace UI
- User registration/login
- Secure HTTP-only session cookie
- PostgreSQL persistence
- Conversation history
- Gemini Interactions API
- Server-side Gemini API key
- Instant / Research / Code / Agent modes
- Plan gates: Free / Plus / Pro / Ultra
- Monthly usage limits
- Paystack monthly subscription initialization
- Paystack webhook signature verification
- NGN pricing configuration
- Responsive mobile UI
- ZCORP website / Telegram / WhatsApp links

## Architecture

```text
Browser
   |
   v
Express API
   |---- Auth + sessions
   |---- Chat + usage limits
   |---- Billing + Paystack
   |
   +---- Gemini API
   |
   +---- PostgreSQL
```

## 1. Install

```bash
npm install
```

## 2. Configure environment

Copy `.env.example` to `.env` and fill in:

- `GEMINI_API_KEY`
- `DATABASE_URL`
- `JWT_SECRET`

For billing, also configure:

- `PAYSTACK_SECRET_KEY`
- `PAYSTACK_PUBLIC_KEY`
- `APP_URL`

**Never commit `.env` or your real Gemini/Paystack secret keys.**

## 3. Database

Create a PostgreSQL database and run:

```bash
psql "$DATABASE_URL" -f schema.sql
```

The server also initializes the schema automatically when `DATABASE_URL` is present.

## 4. Run

```bash
npm run dev
```

Open:

```text
http://localhost:3000
```

## Billing setup

The code uses Paystack's server-side transaction initialization and a signed webhook.

Set your Paystack webhook endpoint to:

```text
https://YOUR-DOMAIN/api/billing/webhook
```

Before going live:
1. Create monthly Plus, Pro and Ultra plans in Paystack.
2. Put their plan codes in `PAYSTACK_PLUS_PLAN_CODE`, `PAYSTACK_PRO_PLAN_CODE`, and `PAYSTACK_ULTRA_PLAN_CODE`.
3. Test the complete checkout and webhook flow with test keys.
4. Configure the webhook URL: `https://YOUR-DOMAIN/api/billing/webhook`.
5. Add subscription cancellation/downgrade handling before launch.

Paystack subscriptions are recurring plans; configure the interval and amount in Paystack rather than trusting client-side prices.

## Gemini

The server uses the official `@google/genai` SDK and the Gemini Interactions API. The model is configurable with:

```text
GEMINI_MODEL=gemini-3.8-flash
```

Do not expose the Gemini key in frontend JavaScript.

## ZCORP details used

- Organization: ZCORP ORG
- Website: https://zcorp-org-co.vercel.app/
- Email: zcorporg40@gmail.com
- Telegram channel: https://t.me/zcorporg
- Telegram group: https://t.me/+M8TTeOV7ElpjMDk0
- WhatsApp channel: https://whatsapp.com/channel/0029VbCoI29AYlUOb6Bdpo30

## Important

This is the foundation for the full ZEUS product. Before calling it production-ready, add:

- email verification
- password reset
- CSRF strategy if your deployment requires it
- admin dashboard
- moderation/abuse controls
- file upload pipeline
- object storage
- advanced memory
- streaming responses
- subscription lifecycle management
- refunds/cancellations
- observability
- automated tests
- CI/CD
- backups
- privacy/terms pages
